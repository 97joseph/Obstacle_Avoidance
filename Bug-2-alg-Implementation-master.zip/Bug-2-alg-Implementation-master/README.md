# Bug-2-alg-Implementation
Implementation of Bug 2 Algorithm, a robotic motion planning algorithm, in Python
